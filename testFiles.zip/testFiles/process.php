<?php
  require "../config/config.php";

  $course_number;
  $course_prefix;
  $teacher_cwid;

  if(isset($_POST['teacherCWID'])){

  	$teacher_cwid = $_POST['teacherCWID'];
  }

  if(isset($_POST['teacherCWID'])){

  	$course_prefix = $_POST['coursePref'];
  }

  if(isset($_POST['teacherCWID'])){

  	$course_number = $_POST['courseNum'];
  }

  echo ( $course_number." ");
  echo ($course_prefix." ".$teacher_cwid);

  $sql = "INSERT INTO leaders (Prefix, Number, Teacher_CWID) VALUES ( '".$course_prefix."', '". $course_number. " ', '". $teacher_cwid."');";
  $result = mysqli_query($con, $sql);

  if (mysqli_query($con, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($con);
}

mysqli_close($con);
  
?>