function _(id){
   return document.getElementById(id);	
}


var droppedIn = false;


function drag_start(event) {
    
    event.dataTransfer.dropEffect = "move";
    event.dataTransfer.setData("text", event.target.getAttribute('id') );
}








function drag_drop(event) {
    event.preventDefault(); /* Prevent undesirable default behavior while dropping */
    var elem_id = event.dataTransfer.getData("text");
    event.target.appendChild( _(elem_id) );
   
   
    droppedIn = true;
}


function drag_end(event) {
    if(droppedIn == false){
       
    }
	droppedIn = false;
}


function readDropZone(){
    
    var elements = document.querySelectorAll(".drop_zone");

    for(i = 0; i < elements.length ; i++){

        alert(this.getAttribute("id"));


    }






    /* Run Ajax request to pass any data to your server */
}

$(document).ready(function(){



    

        $("#submit").click(function(){

            alert("submit Works!");

            testB();

        });



 



   


    

});





 function testB(){

    var listOf = $( ".drop_zone:has(.objects)" );

    listOf.each(function(index, element){

        
        var subject = $(element).attr("id").split(" ");


        var teacherSWID = $(element).children().attr("id");

        var coursePref = subject[0];
        var courseNumber = subject[1];

        processData(teacherSWID, coursePref, courseNumber);

    });

    }

    function processData(teacher, prefix, number ){


        alert("this function have been called");
        alert("teacher CWId is : "+teacher);

        $.post('process.php', { teacherCWID : teacher, 
                     coursePref : prefix,
                     courseNum : number,


        }, function(data) {

            $("#process_feedback").html(data);

        });

    }
