<?php
  require "../config/config.php";
  
?>



<!DOCTYPE HTML>
<html>
<head>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="testStyle.css">
<script src="test.js"></script>


</head>


<body>
<h2 id="app_status">App status...</h2>
<h1>Drop Zone</h1>

<hr>



<div id = "listOfTeachers">

<div id= 'pending' class='drop_zone'ondrop='drag_drop(event)' ondragover= 'return false' ondragleave="return false" >Temporary hold</div>
    
<?php


            //Creating teachers as dragable objects with CWID as object ID

            $sql = "SELECT Fname, Lname, CWID FROM person WHERE role = 'teacher'";

            $result = mysqli_query($con, $sql);

           

            while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){

                $FirstN = $row['Fname'];

                $lastN = $row['Lname'];

                $objectID = $row['CWID'];

                

                //Making a dragable divs with Professors names
                echo "<div id=".$objectID. " class='objects' draggable='true' ondragstart='drag_start(event)' ondragleave='return false'>Professor <br/>".$FirstN." ".$lastN."</div>" ;   

                           

            }
?>
</div>



    <div id="listOfCourses">

     <?php
            //making divs with distinct courses:


            $sql1 = "SELECT DISTINCT Prefix, Number FROM course";

            $result = mysqli_query($con, $sql1);


             while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){

                $pref = $row['Prefix'];

                $number = $row['Number'];

               

                   
                echo "<div id= '".$pref." ".$number."' class='drop_zone' ondrop='drag_drop(event)' ondragover= 'return false' ondragleave= 'drag_leave(event)' >".$pref." ".$number."</div><br/>";
                  

                           

            }

            

            ?>

            <br/>



</div>

<input id = "submit" type = "button" value = "Assign Leaders" />

<div id="process_feedback"></div>

</body>
</html>